#include "zf_common_headfile.h"

#ifndef __IMU963_H__
#define __IMU963_H__

#define ddt 0.005

struct KFP {
    float LastP;
    float wp;
    float out;
    float Kg;
    float Q;
    float R;
    float Now_P;
};

void Get_KFP_angle(void);
float kalmanFilter(struct KFP *kfp,float input);

extern float Angle_KFP;

#endif 
