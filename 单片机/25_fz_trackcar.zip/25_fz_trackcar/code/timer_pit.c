#include "encoder.h"
#include "motor.h"
#include "timer_pit.h"
#include "car_control.h"
#include "mcx_vision.h"
#include "PID.h"
#include "imu963ra.h"
#include "search.h"
#include "imgproc.h"
#include "island.h"


extern uint32 encoder_l;
extern uint32 encoder_r;
extern uint32 encoder_m;
extern volatile int Left_Island_Flag;//�󻷵�
extern volatile int Right_Island_Flag;//�һ���
extern float Angle_Z;

extern uint8 Image_use_zip[IMAGE_H][IMAGE_W];
extern uint8 image_use[IMAGE_H][IMAGE_W];

int gpio_status1,gpio_status2,gpio_status3;
int finish_flag=0;
void pit_handler(void) //��������С������
{
	velocity_control();
}

void pit_handler1(void) //������,�Ҷ��ź�
{
	Get_KFP_angle();
	gpio_status1 = gpio_get_level(D0);
	gpio_status2 = gpio_get_level(D1);  
//	gpio_status3 = gpio_get_level(C30);	
}

void pit_handler2(void) //�����
{
	uint8 set_threshold;
	set_threshold = otsuThreshold(mt9v03x_image[0])+30;
//	set_threshold = 125;
	if(mt9v03x_finish_flag)
	{
		compressimage();//ͼ��ѹ��
//			sobel(Image_use_zip,image_use,set_threshold);//��ֵ��
		sobel_easy(Image_use_zip,image_use,set_threshold);
//			image_filter(image_use);
		mt9v03x_finish_flag = 0;
//			wifi_spi_show();
	}		
	image_draw_rectan(image_use);
	search_begin(image_use);
	clear_find_point();
	search_neighborhood();
		
	//ʮ��
//		Cross_Detect();
	//Բ��
	Island_Detect();
	
	Get_Mid_Line();
	
	finish_flag = find_start_finish_line();
}

void timer_pit_init(void) 
{
	pit_ms_init(PIT_CH0, 3);//�����ж�    	
    interrupt_set_priority(PIT_IRQn, 0);//�������ȼ�
}