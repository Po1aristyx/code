#include "zf_common_headfile.h"

#ifndef CODE_OPENARTMINI_H_
#define CODE_OPENARTMINI_H_

#define UART1_INDEX              (UART_1)                             
#define UART1_BAUDRATE           (9600)                                
#define UART1_TX_PIN             (UART1_TX_B12)                        
#define UART1_RX_PIN             (UART1_RX_B13)                        
#define UART1_PRIORITY           (LPUART1_IRQn)                                  

void op_init();
void uart1_rx_interrupt_handler (void);//op�Ĵ��ڽ���
void uart1_send(void);
uint8 class_get(void);

#endif
