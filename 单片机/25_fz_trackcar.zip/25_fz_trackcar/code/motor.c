#include "motor.h"
#include "math.h"


int16 v_w[3]={0};       //�������ӵ�ת�٣�l,r,m

void motor_init()
{
	//��ʼ�����ͨ��1
	pwm_init(motor_1, 17000, 0);
	gpio_init(motor_1_dir , GPO, 0, GPO_PUSH_PULL);
	//��ʼ�����ͨ��2
	pwm_init(motor_2, 17000, 0);
	gpio_init(motor_2_dir , GPO, 0, GPO_PUSH_PULL);
	//��ʼ�����ͨ��3
	pwm_init(motor_3, 17000, 0);
	gpio_init(motor_3_dir , GPO, 0, GPO_PUSH_PULL);
	//��ʼ�����ͨ��4
	pwm_init(motor_4, 17000, 0);
	gpio_init(motor_4_dir , GPO, 0, GPO_PUSH_PULL);
}

void car_omni(int16 v_x, int16 v_y, int16 v_z)
{
    v_w[0] = v_x/3 + sqrt(3)/3*v_y + v_z/3 - imu963ra_gyro_z/60; // l
    v_w[1] = v_x/3 - sqrt(3)/3*v_y + v_z/3 - imu963ra_gyro_z/60; // r
    v_w[2] = -v_x*2/3 + v_z/3 -  imu963ra_gyro_z/60; // m
}

void motor_l(int speed)
{
	if(speed>=SPEED_MAX)//�޷�����
        speed=SPEED_MAX;
    else if(speed<=SPEED_MIN)
            speed=SPEED_MIN;
	if(speed>0)
	{
		gpio_set_level(motor_1_dir , 0); 
		pwm_set_duty(motor_1, speed); 
	}
	else
	{
		gpio_set_level(motor_1_dir , 1); 
		pwm_set_duty(motor_1, -speed); 
	}
	//tft180_show_float(0, 48, (float)speed, 6, 3); 
}

void motor_r(int speed)
{
	if(speed>=SPEED_MAX)//�޷�����
        speed=SPEED_MAX;
    else if(speed<=SPEED_MIN)
            speed=SPEED_MIN;
	if(speed>0)
	{
		gpio_set_level(motor_2_dir , 1); 
		pwm_set_duty(motor_2, speed); 
	}
	else
	{
		gpio_set_level(motor_2_dir , 0); 
		pwm_set_duty(motor_2, -speed); 
	}
	//tft180_show_float(0, 64, (float)speed, 6, 3); 
}

void motor_m(int speed)
{
    if(speed>=SPEED_MAX)//�޷�����
        speed=SPEED_MAX;
    else if(speed<=SPEED_MIN)
            speed=SPEED_MIN;
	if(speed>0)
	{
		gpio_set_level(motor_3_dir , 0); 
		pwm_set_duty(motor_3, speed);
	}
	else
	{
		gpio_set_level(motor_3_dir , 1); 
		pwm_set_duty(motor_3, -speed);
	}
	//tft180_show_float(0, 64, (float)speed, 6, 3); 
}
