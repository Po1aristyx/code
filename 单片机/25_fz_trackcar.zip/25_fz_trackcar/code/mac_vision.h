#include "zf_common_headfile.h"

#ifndef CODE_MCX_VISION_H_
#define CODE_MCX_VISION_H_

#define UART4_INDEX              (UART_4   )                             
#define UART4_BAUDRATE           (115200)                                
#define UART4_TX_PIN             (UART4_TX_C16  )                        
#define UART4_RX_PIN             (UART4_RX_C17  )                        
#define UART4_PRIORITY           (LPUART4_IRQn)                                  
#define IPS200_TYPE             (IPS200_TYPE_SPI)  

typedef struct
{
    uint16 res_x1;
    uint16 res_y1;
    uint16 res_x2;
    uint16 res_y2;
}od_result_t;

typedef struct {
	uint8 cx;
	uint8 cy;
	uint8 w;
	uint8 h;
}target;

void mcx_init();
void uart4_rx_interrupt_handler (void);//MCX�Ĵ��ڽ���