#include "zf_common_headfile.h"

#ifndef CODE_MCX_VISION_H_
#define CODE_MCX_VISION_H_

#define UART4_INDEX              (UART_4   )                             
#define UART4_BAUDRATE           (115200)                                
#define UART4_TX_PIN             (UART4_TX_C16  )                        
#define UART4_RX_PIN             (UART4_RX_C17  )                        
#define UART4_PRIORITY           (LPUART4_IRQn)                                  
#define IPS200_TYPE             (IPS200_TYPE_SPI)  

typedef struct
{
    uint16 res_x;
    uint16 res_y;
    uint16 res_w;
    uint16 res_h;
}od_result_t;


void mcx_init();
void uart4_rx_interrupt_handler (void);//MCX�Ĵ��ڽ���
void color_result_show(void);
void od_result_clear(void);

#endif
