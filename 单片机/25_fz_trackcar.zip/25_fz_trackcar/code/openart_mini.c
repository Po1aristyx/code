#include "openart_mini.h"

uint8 uart1_get_data[64];                          
uint8 fifo_op_data[64];   
uint8 classify[64];
uint32 fifo_op_count = 0;                       
fifo_struct uart1_data_fifo;
volatile uint16 class_result[10];

extern const uint8 class_type[][16];
extern uint8 class_type_num[15];
extern uint8 class_type_size[15];

void op_init()
{
	//���ڳ�ʼ��------------------------------------
	fifo_init(&uart1_data_fifo, FIFO_DATA_8BIT, uart1_get_data, 64);              // ��ʼ�� fifo ���ػ�����
	uart_init(UART1_INDEX, UART1_BAUDRATE, UART1_TX_PIN, UART1_RX_PIN);          
	//uart_rx_interrupt(UART1_INDEX, ZF_ENABLE);                                   // ���� UART_INDEX �Ľ����ж�
	uart_rx_interrupt(UART1_INDEX, ZF_DISABLE);                                   // �ر� UART_INDEX �Ľ����ж�
	interrupt_set_priority(UART1_PRIORITY, 1);                                   // ���ö�Ӧ UART_INDEX ���ж����ȼ�Ϊ 0
}

void uart1_rx_interrupt_handler (void)//op�Ĵ��ڽ���
{ 
	uint8 get_data = 0;
	
	uart_query_byte(UART1_INDEX, &get_data);  
	fifo_write_buffer(&uart1_data_fifo, &get_data, 1); 
}

void uart1_send(void)
{
	uart_write_string(UART1_INDEX,"1");
}

uint8 class_get(void)
{
	uint32 fifo_op_count=0;
	fifo_op_count = fifo_used(&uart1_data_fifo);
	if(fifo_op_count!=0)
	{
		fifo_read_buffer(&uart1_data_fifo,fifo_op_data, &fifo_op_count,FIFO_READ_AND_CLEAN);
		for(int i=0;i<64;i++)
		{
			classify[i] = fifo_op_data[i];
		}
		
		if(classify[0]==0xFF && classify[1]>=0 && classify[1]<=14){
			tft180_show_uint(0,112,classify[1],8);
			tft180_show_chinese(0, 96, 16,  class_type[class_type_num[classify[1]]], class_type_size[classify[1]], RGB565_RED);
			return classify[1];
		}
	}
	return 20;
}
