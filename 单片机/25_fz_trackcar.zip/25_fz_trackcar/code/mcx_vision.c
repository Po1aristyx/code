#include "mcx_vision.h"

uint8 uart_get_data[64];                          
uint8 fifo_get_data[64];   
uint32 fifo_data_count = 0;                       
fifo_struct uart_data_fifo;

extern int control_mode;

volatile od_result_t od_result={0};

void mcx_init()
{
	//���ڳ�ʼ��------------------------------------
	fifo_init(&uart_data_fifo, FIFO_DATA_8BIT, uart_get_data, 64);              // ��ʼ�� fifo ���ػ�����
	uart_init(UART4_INDEX, UART4_BAUDRATE, UART4_TX_PIN, UART4_RX_PIN);          
	uart_rx_interrupt(UART4_INDEX, ZF_ENABLE);                                   // ���� UART_INDEX �Ľ����ж�
	interrupt_set_priority(UART4_PRIORITY, 0);                                   // ���ö�Ӧ UART_INDEX ���ж����ȼ�Ϊ 0
}

void uart4_rx_interrupt_handler (void)//MCX�Ĵ��ڽ���
{ 
    uint8 get_data = 0;                                              
    uint32 temp_length = 0;
    uint8 od_num = 0;
    uart_query_byte(UART4_INDEX, &get_data);  
    {
        fifo_write_buffer(&uart_data_fifo, &get_data, 1);   
    }

    if(0xFF == get_data)
    {
        temp_length = 1;
        fifo_read_buffer(&uart_data_fifo, fifo_get_data, &temp_length, FIFO_READ_AND_CLEAN);
        if(0xAA == fifo_get_data[0])
        {
            temp_length = 8;
            fifo_read_buffer(&uart_data_fifo, fifo_get_data, &temp_length, FIFO_READ_AND_CLEAN);
            memcpy((uint8*)(&od_result), fifo_get_data, 8);
        }
        fifo_clear(&uart_data_fifo);
    }
}

void color_result_show(void)
{
	tft180_show_int(0, 80, od_result.res_x, 4); 
	tft180_show_int(32, 80, od_result.res_y, 4);
	tft180_show_int(0, 96, od_result.res_w, 4);
	tft180_show_int(32, 96, od_result.res_h, 4);
}

void od_result_clear(void)
{
	od_result.res_x = 0;
	od_result.res_y = 0;
	od_result.res_w = 0;
	od_result.res_h = 0;
}
