#include "zf_common_headfile.h"

#ifndef __CONTROL_H__
#define __CONTROL_H__

#define IMAGE_H    50//ͼ��߶�
#define IMAGE_W    90//ͼ�����

void position_correct(void);
void color_result_process(void);
void velocity_control(void);
int get_road_angle(void);

#endif

