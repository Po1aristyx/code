#include "zf_common_headfile.h"

#ifndef CODE_SCREEN_H_
#define CODE_SCREEN_H_

#define IMAGE_H    50//ͼ��߶�
#define IMAGE_W    90//ͼ�����

#define INCLUDE_BOUNDARY_TYPE  1
#define WIFI_SSID_TEST          "fff"
#define WIFI_PASSWORD_TEST      "fz12345678" 
#define BOUNDARY_NUM            (IMAGE_H * 3 / 2)

void class_show(void);
void Line_show(void);
void wifi_spi_show(void);

#endif