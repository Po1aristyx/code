#include "car_control.h"
#include "PID.h"
#include "motor.h"
#include "encoder.h"
#include "search.h"
#include "mcx_vision.h"
#include "math.h"
#include "openart_mini.h"

int speed_x;
int speed_y;
float offset_base = 1;
int v_z;

extern uint32 encoder_l;
extern uint32 encoder_r;
extern uint32 encoder_m;

extern uint16 Mid_Line[IMAGE_H];	//����

extern int16 v_w[3];       //�������ӵ�ת�٣�l,r,m

extern volatile od_result_t od_result;

extern uint8 class_reward[20];
extern int class_num;

extern fifo_struct uart1_data_fifo;

int control_mode = 0;

int target_x = 75;
int target_y = 70;
int target_w = 70;
int16 target_distance = 15;

extern float Angle_Z,Angle_KFP;

extern int gpio_status1,gpio_status2,gpio_status3;

float Target_Z = 0;
//ͣ��
void stop_car(void)
{
	control_mode = 4;
	system_delay_ms(50);
}

void position_correct(void)
{
	if(od_result.res_x != 0 && od_result.res_y != 0)
	{
		speed_x = (od_result.res_x-target_x)*0.3;
		speed_y = -(od_result.res_w-target_w)*0.35;
		v_z = 0;
//		speed_x = func_limit(v_z,5);
//		speed_y = func_limit(v_z,5);
		
//		v_z = -angle_pid(Angle_KFP,Target_Z);
	}
	else
	{
		speed_x = 0;
		speed_y = 0;
//		v_z = -angle_pid(Angle_KFP,Target_Z);
	}
}

//ת�������ұ�
void push_block_left(void)
{
//	Angle_Z = Angle_KFP;
	Target_Z = Angle_Z + 90;
	while(abs(Angle_KFP - Target_Z)>5)
	{
		control_mode = 2;
		v_w[0] = 5;
		v_w[1] = 5;
		system_delay_ms(50);
	}
}

//ת���������
void push_block_right(void)
{
	Angle_Z = Angle_KFP;
	Target_Z = Angle_Z - 90;
	while(abs(Angle_KFP - Target_Z)>5)
	{
		control_mode = 2;
		v_w[0] = 5;
		v_w[1] = 5;
		system_delay_ms(50);
	}
	
}


//�����������
void middle_correct(void)
{
    int16 sum = 0;
    for(uint8 i = 10; i <= 25; i++)
    {
        sum += (Mid_Line[IMAGE_H-i] - IMAGE_W/2);
    }
    speed_x = sum;
    v_z = sum * 15;
	
	if(sum <= 10)
		control_mode = 0;
}

//��ȡ�����Ƕ�
int get_road_angle(void)
{
	int angle = 0;
	float sum1 = 0,sum2 = 0;
	float slope = 0;
	
	for(uint8 i = 10; i <= 25; i++)
    {
        sum1 += Mid_Line[IMAGE_H-i] - IMAGE_W/2;
		sum2 += i - 10;
    }
	slope = sum1/(sum2+1);
	
	angle = atan(slope)*180/PI;
	
	return angle;
}
//�ҵ��������˶�����
void color_result_process(void)
{
	int16 temp_distance = 0;		//�������
	
	if(od_result.res_h>=30 && od_result.res_w>=30)
	{
		stop_car();
		system_delay_ms(300);
//		control_mode = 3;		//��������
//		system_delay_ms(500);
		
		pit_disable(PIT_CH2);	//�ر�������ж�
		system_delay_ms(50);
		
//		gpio_set_level(D4, 1);              //����
//		temp_distance = sqrt(pow(od_result.res_x - target_x, 2)+pow(od_result.res_w - target_w, 2));
		stop_car();
		Angle_Z = Angle_KFP;
		Target_Z = Angle_Z;
		
		control_mode = 7;
		while(abs(od_result.res_x - target_x)>12)  //��ǰ�����Ƕȶ�������
		{
			Angle_Z = Angle_KFP;
			Target_Z = Angle_Z + (target_x - od_result.res_x)/2;
			system_delay_ms(25);
		}
		
		Angle_Z = Angle_KFP;
		Target_Z = Angle_Z;
		control_mode = 1;
		while(abs(od_result.res_x - target_x)>12 || abs(od_result.res_w - target_w)>8 ); //�������
//		while(temp_distance>target_distance)		
//		{
//			temp_distance = sqrt(pow(od_result.res_x - target_x, 2)+pow(od_result.res_w - target_w, 2));
//		}
		stop_car();
		
		uart_write_string(UART1_INDEX,"1");		//��ʼ����ʶ��
		uart_rx_interrupt(UART1_INDEX, ZF_ENABLE);
		fifo_clear(&uart1_data_fifo);
		uint8 result = 20;  //����һ�����֮�������
		while(result == 20)
		{
			result = class_get();
			system_delay_ms(100);
		}
		tft180_show_uint(32,112,result,8);
		class_num += 1;
		class_reward[class_num] = result;
		
		gpio_set_level(D4, 0);              //�رղ���
		uart_write_string(UART1_INDEX,"0");		//�رշ���ʶ��
		uart_rx_interrupt(UART1_INDEX, ZF_DISABLE);
		
		fifo_clear(&uart1_data_fifo);
		
		//ת��׼���Ʒ���
		push_block_left();
		stop_car();
		
		//ת������
//		gpio_set_level(D4, 1);              //����
//		temp_distance = sqrt(pow(od_result.res_x - target_x, 2)+pow(od_result.res_y - target_y, 2));
		control_mode = 1;
		while(abs(od_result.res_x - target_x) > 8);
		stop_car();
		gpio_set_level(D4, 0);              //�رղ���
		
		Angle_Z = Angle_KFP;
		Target_Z = Angle_Z;
		control_mode = 5;
		int stop_flag = 0,left_flag = 0,right_flag =0;
		int last_statues1 = gpio_status1, last_statues2 = gpio_status2;
		
		while(!stop_flag)
		{
			if(last_statues1==0  && gpio_status1==1)
				left_flag = 1;
		
			if(last_statues2==0  && gpio_status2==1)
				right_flag = 1;
			
			last_statues1 = gpio_status1;
			last_statues2 = gpio_status2;
			
			if(left_flag==1 && right_flag==1)
				stop_flag = 1;
			else if(left_flag==1 && right_flag==0)
			{
				control_mode = 7;
				Angle_Z = Angle_KFP;
				Target_Z = Angle_Z + 10;
			}
			else if(left_flag==0 && right_flag==1)
			{
				control_mode = 7;
				Angle_Z = Angle_KFP;
				Target_Z = Angle_Z - 10;
			}
				
//			tft180_show_int(0, 96, gpio_status1, 4);  
//			tft180_show_int(32, 96, gpio_status2, 4);
			system_delay_ms(25);

		}
		stop_car();
		
		Angle_Z = Angle_KFP;
		Target_Z = Angle_Z;
		control_mode = 6;
		while(gpio_status1!=0 || gpio_status2!=0)
		{
			system_delay_ms(25);
		}
		system_delay_ms(75);
		stop_car();
		
		Angle_Z = Angle_KFP;		//�ص�����ת����������
		Target_Z = Angle_Z-90;
		while(abs(Angle_KFP - Target_Z)>3)
		{
			control_mode = 7;
			system_delay_ms(50);
		}
		
		pit_enable(PIT_CH2);	//����������ж�
		system_delay_ms(50);
		control_mode = 3;		//��������
		system_delay_ms(300);
		stop_car();
		
		control_mode = 0;
		
		od_result_clear();
	}
}

void velocity_control()
{
	encoder_get();
	
	switch(control_mode)
    {
		case 0:					//����Ѱ��
			//����ƫ����
			v_z = get_offset()*offset_base;
			//����б��
//			road_slope = get_slope(0);
//			v_z = Turn_Road(0,road_slope);
			speed_x = 0;
			speed_y = 80;
			break;
		
		case 1:					//��ɫ�������
			position_correct();
			break;
		
		case 2:
			v_z = -angle_pid(Angle_KFP,Target_Z);		//ת��׼���Ʒ���
			v_w[2] = -v_z/2;
			break;
			
		case 3:
			speed_x = 0;
			speed_y = 0;
			v_z = get_offset()*0.35;	//������������
            break;
		
		case 4:					//ͣ��
			speed_x = 0;
			speed_y = 0;
			v_z = 0;
			break;
		
		case 5:					//��ǰ������
			speed_x = 0;
			speed_y = 60;
			v_z = -angle_pid(Angle_KFP,Target_Z);
			break;
		
		case 6:					//���˻ص�����
			speed_x = 0;
			speed_y = -60;
			v_z = -angle_pid(Angle_KFP,Target_Z);
			break;
		
		case 7:
			speed_x = 0;
			speed_y = 0;
			v_z = -angle_pid(Angle_KFP,Target_Z);		//����ת��
			v_z = func_limit(v_z,200);
			break;
		
		case 8:					//���ɿ���
			break;
			
	}
	if(control_mode != 2)
		car_omni(speed_x,speed_y,-v_z);
	
	motor_l(Incremental_PI(1,v_w[0],encoder_l));
	motor_r(Incremental_PI(2,v_w[1],encoder_r));
	motor_m(Incremental_PI(3,v_w[2],encoder_m));
}