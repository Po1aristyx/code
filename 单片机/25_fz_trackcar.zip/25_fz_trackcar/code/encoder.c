#include "encoder.h"

uint32 encoder_l = 0;
uint32 encoder_r = 0;
uint32 encoder_m = 0;

void encoder_init(void)
{
	encoder_quad_init(QTIMER1_ENCODER1,QTIMER1_ENCODER1_CH1_C0,QTIMER1_ENCODER1_CH2_C1);
	encoder_quad_init(QTIMER1_ENCODER2,QTIMER1_ENCODER2_CH1_C2, QTIMER1_ENCODER2_CH2_C24);
	encoder_quad_init(QTIMER2_ENCODER1,QTIMER2_ENCODER1_CH1_C3, QTIMER2_ENCODER1_CH2_C4);
}

void encoder_get(void)
{
	encoder_l = -encoder_get_count(QTIMER1_ENCODER1);
	encoder_r = -encoder_get_count(QTIMER1_ENCODER2);
	encoder_m = -encoder_get_count(QTIMER2_ENCODER1);

	encoder_clear_count(QTIMER1_ENCODER1);
	encoder_clear_count(QTIMER1_ENCODER2);
	encoder_clear_count(QTIMER2_ENCODER1);
	
	/*tft180_show_int(0, 48, encoder_1, 4); 
	tft180_show_int(0, 64, encoder_2, 4); 
	tft180_show_int(0, 80, encoder_3, 4); 
	tft180_show_int(0, 96, encoder_4, 4); */
}